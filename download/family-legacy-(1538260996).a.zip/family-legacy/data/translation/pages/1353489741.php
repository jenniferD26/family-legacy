<?php 
// Translation strings
__('Other Content', 'runway');
__('Headers and Footers', 'runway');
__('Header', 'runway');
__('Header Content', 'runway');
__('Footers', 'runway');
__('Footer Content', 'runway');
__('Set the header and footer content.', 'runway');
__('The content to appear in the header below the logo and menu.', 'runway');
__('The content to appear in the footer.', 'runway');
?>