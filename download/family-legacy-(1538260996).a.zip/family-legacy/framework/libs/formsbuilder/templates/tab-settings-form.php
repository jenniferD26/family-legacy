<script id="tab-settings" type="text/x-jquery-tmpl">

    <form class="settings-head">

        <input data-set="index" type="hidden" name="index" value="${index}">

		<div class="settings-container">
			<label class="settings-title">
				<?php _e( 'Tab title', 'runway' ); ?>:<br>
				<span class="settings-title-caption"></span>
			</label>
			<div class="settings-in">
				<input class="settings-input" data-set="title" type="text" name="title" value="${title}" />
				<span class="settings-field-caption"></span>
			</div>
		</div>

		<div class="clear"></div>

    </form>

</script>
