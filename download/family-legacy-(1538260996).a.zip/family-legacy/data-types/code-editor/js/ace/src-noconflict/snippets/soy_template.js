ace.define('ace/snippets/soy_template', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "soy_template";

});
